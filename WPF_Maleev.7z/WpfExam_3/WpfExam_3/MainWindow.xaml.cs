﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfExam_3
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       
        public MainWindow()
        {
           
            InitializeComponent();
           
            productGrid.ItemsSource = Listdata();
        }

        private List<Product> Listdata()
        {
             List<Product> bList = new List<Product>();
              bList.Add(new Product {Category="Computer", ModelNumber = 22,ModelName = "ASUS",Price = 5000,PriceBase = 4000,Info = "super puper"} );
                bList.Add(new Product
            {
                Category = "Phone",
                ModelNumber = 3310,
                ModelName = "Nokia",
                Price = 3000,
                PriceBase = 2000,
                Info = "super puper phone"
            });
               bList.Add( new Product {Category="Computer", ModelNumber = 32,ModelName = "ASUS",Price = 6000,PriceBase = 5000,Info = "super puper comp" });
               bList.Add(  new Product {Category="Car", ModelNumber = 2110,ModelName = "LADA",Price = 15000,PriceBase = 14000,Info = "super puper car" });
               bList.Add(  new Product {Category="Car", ModelNumber = 2210,ModelName = "LADA",Price = 25000,PriceBase = 24000,Info = "super puper car" });
               bList.Add(new Product { Category = "Car", ModelNumber = 333210, ModelName = "LADA", Price = 25000, PriceBase = 30000, Info = "super puper car" });
               bList.Add(new Product { Category = "Car", ModelNumber = 66666, ModelName = "LADA", Price = 100, PriceBase = 50, Info = "super puper car" });
            bList.Add(new Product
            {
                Category = "Phone",
                ModelNumber = 7,
                ModelName = "Iphone",
                Price = 15000,
                PriceBase = 14500,
                Info = "super puper iphone"
            });
            bList.Add(new Product
            {
                Category = "Phone",
                ModelNumber = 3610,
                ModelName = "Nokia",
                Price = 3000,
                PriceBase = 2990,
                Info = "super puper phone"
            });
            return bList;
        }
        

       
            
               
        }
       
    


    public class Product
    {
        public string Category { get; set; }
        public int ModelNumber { get; set; }
        public string ModelName { get; set; }
        public int Price { get; set; }
        public int PriceBase { get; set; }
        public string Info { get; set; }
    }
}
