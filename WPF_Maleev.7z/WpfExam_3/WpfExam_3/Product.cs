﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfExam_3
{
    class Product
    {
        private string cat { get; set; }
        private int num { get; set; }
        private string name { get; set; }
        private decimal price { get; set; }
        private decimal base_price { get; set; }
        private string info { get; set; }

        public Product(string cat,int num,string name,decimal price,decimal baseprice,string info)
        {
            this.base_price = baseprice;
            this.cat = cat;
            this.info = info;
            this.name = name;
            this.num = num;
            this.price = price;
        }

        public override string ToString()
        {
            return $"{cat} {num} {name} {price} {base_price} {info}";
        }
    }
}
